# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TestMultilist::Application.config.secret_token = 'eb55034d880416a605e5608ad0493a41f6df65f8b3c483f7c4bfb513c646eb22734a61ace35489e3af701a5fcb0052db908528f4cbdc902878462bafbfe0320a'

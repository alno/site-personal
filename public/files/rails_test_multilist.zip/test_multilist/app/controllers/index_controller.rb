class IndexController < ApplicationController

  def index
    @models = Post.find_by_sql("SELECT id,type,created_at,updated_at,title,description,NULL AS text FROM posts UNION SELECT id,type,created_at,updated_at,NULL as title, NULL AS description, text FROM questions ORDER BY created_at DESC")
  end

end

class Question < ActiveRecord::Base
end
